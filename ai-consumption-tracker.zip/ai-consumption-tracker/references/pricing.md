# Cortex Pricing References

## Where to Find Official Pricing

Snowflake publishes credit-per-token rates in the **Service Consumption Table**:
- URL: https://www.snowflake.com/legal/service-consumption-table/

This is the authoritative source for per-model pricing. Rates change as new models are added.

---

## How Pricing Works

- Each LLM model has distinct **credits-per-million-token** rates for input and output tokens.
- Some models also bill for `cache_read_input` and `cache_write_input` token types (visible in `CREDITS_GRANULAR` and `TOKENS_GRANULAR` columns).
- Rates differ by model — larger, more capable models cost more per token.

---

## Pre-Computed Credits vs Manual Calculation

| View | Credits Pre-Computed? | Column |
|------|-----------------------|--------|
| `CORTEX_AI_FUNCTIONS_USAGE_HISTORY` | Yes | `CREDITS` |
| `CORTEX_AGENT_USAGE_HISTORY` | Yes | `TOKEN_CREDITS` |
| `SNOWFLAKE_COCO_USAGE_HISTORY` | Yes | `TOKEN_CREDITS` |
| `SNOWFLAKE_COWORK_USAGE_HISTORY` | Yes | `TOKEN_CREDITS` |
| `CORTEX_ANALYST_USAGE_HISTORY` | Yes | `CREDITS` |
| `CORTEX_AI_GUARDRAILS_USAGE_HISTORY` | Yes | `TOKEN_CREDITS` |
| `CORTEX_SEARCH_DAILY_USAGE_HISTORY` | Yes | `CREDITS` |
| `CORTEX_FINE_TUNING_USAGE_HISTORY` | Yes | `TOKEN_CREDITS` |
| `CORTEX_PROVISIONED_THROUGHPUT_USAGE_HISTORY` | Yes | `PTU_CREDITS` |
| `CORTEX_REST_API_USAGE_HISTORY` | **No** — tokens only | `TOKENS` |

For all views except `CORTEX_REST_API_USAGE_HISTORY`, the credits column already reflects correct rates. Do not manually recalculate.

For `CORTEX_REST_API_USAGE_HISTORY`, apply rates from the Service Consumption Table to the token counts manually.

---

## Provisioned Throughput (PTU)

- Reserved-capacity SKU billed continuously for the term.
- Tracked in `CORTEX_PROVISIONED_THROUGHPUT_USAGE_HISTORY` with `PTU_CREDITS`.
- Not request-level — a fixed cost for guaranteed throughput.

---

## Token Counting Before Execution

Use `AI_COUNT_TOKENS` to estimate token count before running an expensive query:

```sql
SELECT AI_COUNT_TOKENS('claude-3-5-sonnet', 'Your prompt text here');
```

This helps predict costs before committing to a large batch operation.
