# CoCo Per-User Daily Credit Limits

## Parameters

| Parameter | Controls |
|-----------|----------|
| `CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER` | CoCo CLI |
| `CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER` | CoCo Desktop |
| `CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER` | CoCo in Snowsight |

## Values

| Value | Behavior |
|-------|----------|
| `-1` (default) | No limit — unlimited access |
| `0` | Access blocked entirely for the surface |
| Positive number | Access blocked when estimated usage in rolling 24-hour window exceeds this value |

User-level settings override account-level settings for that user.

Requires ACCOUNTADMIN (or a role with privileges to modify the account/user object).

---

## Set Account-Level Defaults

```sql
-- Set daily limits for all users across all surfaces
ALTER ACCOUNT SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER ACCOUNT SET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER ACCOUNT SET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
```

## Remove Account-Level Limits (Restore Unlimited)

```sql
ALTER ACCOUNT UNSET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER;
ALTER ACCOUNT UNSET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER;
ALTER ACCOUNT UNSET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER;
```

## Set Per-User Overrides

```sql
-- Higher limit for a power user
ALTER USER power_user SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 50;

-- Block a specific user from Snowsight CoCo
ALTER USER restricted_user SET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER = 0;
```

## Remove Per-User Overrides (Fall Back to Account Level)

```sql
ALTER USER jsmith UNSET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER;
ALTER USER jsmith UNSET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER;
ALTER USER jsmith UNSET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER;
```

## Block All Users, Then Allow Specific Users

```sql
-- Block CoCo Desktop for everyone
ALTER ACCOUNT SET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER = 0;

-- Allow specific user with a 20 credit/day cap
ALTER USER power_user SET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
```

## Audit Users with Custom Limits

```sql
EXECUTE IMMEDIATE $$
DECLARE
  target_user STRING;
  rs_users RESULTSET;
  res RESULTSET;
BEGIN
  CREATE OR REPLACE TEMPORARY TABLE _param_overrides (user_name STRING, param_value STRING);

  SHOW USERS;
  rs_users := (SELECT "name" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));

  FOR record IN rs_users DO
    target_user := record."name";
    EXECUTE IMMEDIATE
      'SHOW PARAMETERS LIKE ''CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER'' IN USER "' || :target_user || '"';
    INSERT INTO _param_overrides (user_name, param_value)
      SELECT :target_user, "value"
      FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
      WHERE "level" = 'USER';
  END FOR;

  res := (SELECT * FROM _param_overrides);
  RETURN TABLE(res);
END;
$$;
```

> Change the parameter name in the `SHOW PARAMETERS LIKE` clause to audit Desktop or Snowsight limits.

## Relationship to Other Controls

- **CoCo daily limits**: Quick per-surface cap, rolling 24-hour window, account or user level.
- **Quotas** (`SNOWFLAKE.CORE.QUOTA`): More flexible — monthly/daily, notifications, block enforcement, custom actions on breach.
- **Budgets** (`SNOWFLAKE.CORE.BUDGET`): Spending visibility and alerts, shared resource tracking, no per-user enforcement.

These three mechanisms are **complementary** — use any combination.
