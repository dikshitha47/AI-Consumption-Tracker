# Per-User Quotas for AI

## Key Concepts

- Quotas are class instances (`SNOWFLAKE.CORE.QUOTA`).
- Set monthly or daily per-user credit limits.
- Optional block enforcement to actually prevent usage when limit is breached.
- AI-credit domains (`AI FUNCTION`, `CORTEX AGENT`, `CORTEX_CODE`, `SNOWFLAKE INTELLIGENCE`) cannot be mixed with `WAREHOUSE` domain in one quota.

---

## Create a Quota

```sql
USE SCHEMA my_db.my_schema;
CREATE SNOWFLAKE.CORE.QUOTA my_ai_quota();
```

## Set Per-User Limits

```sql
-- Monthly limit
CALL my_db.my_schema.my_ai_quota!SET_PER_USER_LIMIT(500, 'MONTHLY');

-- Daily limit
CALL my_db.my_schema.my_ai_quota!SET_PER_USER_LIMIT(50, 'DAILY');
```

## Enable Block Enforcement

By default, quotas only notify — they don't block. Enable blocking:

```sql
CALL my_db.my_schema.my_ai_quota!SET_BLOCK_ENFORCEMENT_ENABLED(TRUE);
```

## Scope to Users

```sql
-- Apply to all users
CALL my_db.my_schema.my_ai_quota!SET_USER_TAGS([], 'ALL_USERS');

-- Apply to users with a specific tag value
CALL my_db.my_schema.my_ai_quota!SET_USER_TAGS(
    [[(SELECT SYSTEM$REFERENCE('TAG', 'my_db.tags.department', 'SESSION', 'APPLYBUDGET')), 'analytics']],
    'UNION'
);
```

## Add AI Shared Resources

```sql
-- All AI Functions
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('AI FUNCTION');

-- Specific AI function
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('AI FUNCTION', 'AI_COMPLETE');

-- All CoCo surfaces
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('CORTEX_CODE');

-- Specific CoCo surface
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('CORTEX CODE', 'CORTEX_CODE_CLI');
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('CORTEX CODE', 'CORTEX_CODE_SNOWSIGHT');

-- All Cortex Agents
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('CORTEX AGENT');

-- Specific Cortex Agent
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE(
    'CORTEX AGENT',
    (SELECT SYSTEM$REFERENCE('CORTEX_AGENT', 'my_db.my_schema.my_agent', 'SESSION', 'USAGE'))
);

-- Snowflake Intelligence (CoWork)
CALL my_db.my_schema.my_ai_quota!ADD_SHARED_RESOURCE('SNOWFLAKE INTELLIGENCE');
```

## Configure Notifications

```sql
-- Set notification thresholds (percentage of limit)
CALL my_db.my_schema.my_ai_quota!SET_NOTIFICATION_THRESHOLDS(
    PARSE_JSON('[{"threshold_type": "ACTUAL", "threshold_value": 80}]')
);

-- Set email recipients
CALL my_db.my_schema.my_ai_quota!SET_EMAIL_NOTIFICATIONS(
    PARSE_JSON('["admin@company.com"]')
);
```

## Configure Custom Actions on Breach

```sql
-- Run a stored procedure when a user breaches the limit
CALL my_db.my_schema.my_ai_quota!SET_CUSTOM_ACTIONS(
    PARSE_JSON('[{"action_type": "ON_BREACH", "action": "CALL my_db.my_schema.handle_quota_breach()"}]')
);
```

## Inspect Quota State

```sql
-- List all quotas
SHOW SNOWFLAKE.CORE.QUOTA INSTANCES IN ACCOUNT;

-- Get full config
CALL my_db.my_schema.my_ai_quota!GET_CONFIG();

-- Get shared resources
CALL my_db.my_schema.my_ai_quota!GET_SHARED_RESOURCES();
```

## Exclude Specific Users

```sql
-- Exclude a service account from quota enforcement
CALL my_db.my_schema.my_ai_quota!EXCLUDE_USERS(
    PARSE_JSON('["SERVICE_ACCOUNT_USER"]')
);
```

## Drop a Quota

```sql
DROP SNOWFLAKE.CORE.QUOTA my_db.my_schema.my_ai_quota;
```
