# AI Cost Attribution

## Key Constraint

**`QUERY_TAG` / `ALTER SESSION SET QUERY_TAG` does NOT work for AI cost attribution.**
None of the AI usage-history views have a `QUERY_TAG` column. Use user tags or object tags instead.

---

## Attribution Methods

| Method | Mechanism | Products Covered |
|--------|-----------|-----------------|
| **User tag attribution** | `ALTER USER ... SET TAG` + join `TAG_REFERENCES` | AI Functions, CoCo, Agents, CoWork, Guardrails, Analyst (direct only) |
| **Agent tag attribution** | `AGENT_TAGS` array in `CORTEX_AGENT_USAGE_HISTORY` | Cortex Agents |
| **CoWork tag attribution** | `SNOWFLAKE_COWORK_TAGS` array in `SNOWFLAKE_COWORK_USAGE_HISTORY` | Snowflake CoWork |

---

## Set Up User-Tag-Based Cost Attribution

### Step 1: Create a Tag

```sql
CREATE TAG IF NOT EXISTS my_db.tags.cost_center ALLOWED_VALUES = 'engineering', 'analytics', 'data-science', 'marketing';
```

### Step 2: Tag Users

```sql
ALTER USER alice SET TAG my_db.tags.cost_center = 'engineering';
ALTER USER bob SET TAG my_db.tags.cost_center = 'analytics';
```

### Step 3: Query AI Spend by Tag

```sql
SELECT
    tr.TAG_VALUE AS cost_center,
    ROUND(SUM(h.CREDITS), 4) AS total_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_FUNCTIONS_USAGE_HISTORY h
JOIN SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES tr
    ON tr.OBJECT_ID = h.USER_ID
    AND tr.TAG_NAME = 'COST_CENTER'
    AND tr.DOMAIN = 'USER'
WHERE h.START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY tr.TAG_VALUE
ORDER BY total_credits DESC;
```

### CoCo Spend by User Tag

```sql
SELECT
    tr.TAG_VALUE AS cost_center,
    ROUND(SUM(h.TOKEN_CREDITS), 4) AS total_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY h
JOIN SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES tr
    ON tr.OBJECT_ID = h.USER_ID
    AND tr.TAG_NAME = 'COST_CENTER'
    AND tr.DOMAIN = 'USER'
WHERE h.USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY tr.TAG_VALUE
ORDER BY total_credits DESC;
```

---

## AI Guardrails: Additive Cost

AI Guardrails credits are **additive** — they're charged on top of the triggering product's credits. The `AGENTIC_SOURCE` column identifies which product triggered them:

- `CORTEX_CODE_CLI`, `CORTEX_CODE_DESKTOP`, `CORTEX_CODE_SNOWSIGHT`
- `CORTEX_AGENT`
- `SNOWFLAKE_INTELLIGENCE`

```sql
SELECT
    AGENTIC_SOURCE,
    ROUND(SUM(TOKEN_CREDITS), 4) AS guardrail_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_GUARDRAILS_USAGE_HISTORY
WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY AGENTIC_SOURCE
ORDER BY guardrail_credits DESC;
```

---

## What Cannot Be Attributed to a User

| Product | Reason |
|---------|--------|
| Cortex REST API | Has `USER_ID` but no credits column |
| Cortex Search | Has credits but no user column |
| Cortex Fine-Tuning | No user column |
| Cortex Provisioned Throughput | Reserved capacity, not per-request |

---

## Top AI Spenders by User

```sql
WITH user_spend AS (
    SELECT USER_ID, 'AI Functions' AS product, SUM(CREDITS) AS credits
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_FUNCTIONS_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    GROUP BY USER_ID
    UNION ALL
    SELECT USER_ID, 'CoCo', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY
    WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    GROUP BY USER_ID
    UNION ALL
    SELECT USER_ID, 'Cortex Agents', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AGENT_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    GROUP BY USER_ID
    UNION ALL
    SELECT USER_ID, 'CoWork', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COWORK_USAGE_HISTORY
    WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    GROUP BY USER_ID
)
SELECT
    u.NAME AS user_name,
    s.product,
    ROUND(s.credits, 4) AS credits
FROM user_spend s
JOIN SNOWFLAKE.ACCOUNT_USAGE.USERS u ON u.USER_ID = s.USER_ID
WHERE s.credits > 0
ORDER BY s.credits DESC
LIMIT 50;
```
