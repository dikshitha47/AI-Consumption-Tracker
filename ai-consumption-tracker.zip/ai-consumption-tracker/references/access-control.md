# AI Access Control

## Two-Layer Access Model

Users need **both** of these to use Cortex AI Functions:

1. **Account-level privilege**: `USE AI FUNCTIONS` (granted to `PUBLIC` by default)
2. **Database role**: `SNOWFLAKE.CORTEX_USER` or `SNOWFLAKE.AI_FUNCTIONS_USER` (both granted to `PUBLIC` by default)

---

## CORTEX_USER vs AI_FUNCTIONS_USER

| Role | Scope | Default Grant |
|------|-------|---------------|
| `SNOWFLAKE.CORTEX_USER` | AI Functions + Cortex Agents + Cortex Search + other Cortex features | `PUBLIC` |
| `SNOWFLAKE.AI_FUNCTIONS_USER` | AI Functions only (narrower) | `PUBLIC` |

`AI_FUNCTIONS_USER` (GA since Apr 2, 2026) lets you grant AI function access **without** enabling other Cortex features. Useful when you want a role to call AI functions but not use Cortex Agents or Search.

---

## Restrict AI Functions to Specific Roles

```sql
USE ROLE ACCOUNTADMIN;

-- Remove blanket access
REVOKE USE AI FUNCTIONS ON ACCOUNT FROM ROLE PUBLIC;
REVOKE DATABASE ROLE SNOWFLAKE.CORTEX_USER FROM ROLE PUBLIC;
REVOKE IMPORTED PRIVILEGES ON DATABASE SNOWFLAKE FROM ROLE PUBLIC;

-- Grant to a specific role
CREATE ROLE cortex_user_role;
GRANT USE AI FUNCTIONS ON ACCOUNT TO ROLE cortex_user_role;
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE cortex_user_role;
GRANT ROLE cortex_user_role TO USER some_user;
```

## Grant AI Functions Only (No Other Cortex Features)

```sql
USE ROLE ACCOUNTADMIN;

-- Revoke broad Cortex access
REVOKE DATABASE ROLE SNOWFLAKE.CORTEX_USER FROM ROLE my_role;

-- Grant narrow AI-functions-only access
GRANT DATABASE ROLE SNOWFLAKE.AI_FUNCTIONS_USER TO ROLE my_role;

-- Ensure the account privilege is present
GRANT USE AI FUNCTIONS ON ACCOUNT TO ROLE my_role;
```

---

## Per-Function Privileges

For fine-grained control over individual AI functions:

```sql
USE ROLE ACCOUNTADMIN;

-- Remove blanket access
REVOKE USE AI FUNCTIONS ON ACCOUNT FROM ROLE PUBLIC;

-- Grant only specific functions
CREATE ROLE ai_analyst_role;
GRANT USE AI FUNCTION AI_COMPLETE ON ACCOUNT TO ROLE ai_analyst_role;
GRANT USE AI FUNCTION AI_CLASSIFY ON ACCOUNT TO ROLE ai_analyst_role;
GRANT USE AI FUNCTION AI_EXTRACT ON ACCOUNT TO ROLE ai_analyst_role;
GRANT DATABASE ROLE SNOWFLAKE.AI_FUNCTIONS_USER TO ROLE ai_analyst_role;
GRANT ROLE ai_analyst_role TO USER analyst_user;
```

### Supported Per-Function Privilege Names

`AI_COMPLETE`, `AI_CLASSIFY`, `AI_FILTER`, `AI_AGG`, `AI_EMBED`, `AI_EXTRACT`, `AI_SENTIMENT`, `AI_SUMMARIZE_AGG`, `AI_SIMILARITY`, `AI_TRANSCRIBE`, `AI_PARSE_DOCUMENT`, `AI_REDACT`, `AI_TRANSLATE`, `AI_COUNT_TOKENS`, `COMPLETE`, `CLASSIFY_TEXT`, `COUNT_TOKENS`, `EMBED_TEXT`, `ENTITY_SENTIMENT`, `EXTRACT_ANSWER`, `PARSE_DOCUMENT`, `SENTIMENT`, `SUMMARIZE`, `SUMMARIZE_AGG`, `TRANSLATE`, `TRY_COMPLETE`

### View Per-Function Grants

```sql
SHOW GRANTS TO ROLE ai_analyst_role;
SHOW GRANTS ON ACCOUNT;
```

---

## Model Access Control

Control which LLM models a role can use:

```sql
-- Show available models
SHOW CORTEX BASE MODELS IN SCHEMA SNOWFLAKE.MODELS;

-- Grant all models
GRANT APPLICATION ROLE SNOWFLAKE.CORTEX-MODEL-ROLE-ALL TO ROLE my_role;

-- Grant a specific model (role name format: model-specific application roles)
-- Check SHOW CORTEX BASE MODELS for available model roles
```

---

## Opt Out of All AI Features Account-Wide

```sql
USE ROLE ACCOUNTADMIN;

-- Revoke the database role from PUBLIC
REVOKE DATABASE ROLE SNOWFLAKE.CORTEX_USER FROM ROLE PUBLIC;
REVOKE IMPORTED PRIVILEGES ON DATABASE SNOWFLAKE FROM ROLE PUBLIC;

-- Revoke account privilege
REVOKE USE AI FUNCTIONS ON ACCOUNT FROM ROLE PUBLIC;
```

Then selectively re-grant to approved roles.

---

## Using AI Functions with Restricted Caller's Rights (SPCS, Native Apps)

```sql
-- Grant to the session role
GRANT USE AI FUNCTIONS ON ACCOUNT TO ROLE chatbot_user_role;

-- Grant caller version to the service/app owner role
GRANT CALLER USE AI FUNCTIONS ON ACCOUNT TO ROLE service_owner_role;
```

> Note: `USE AI FUNCTIONS` does NOT currently apply to AI function queries inside Snowflake Native Applications — they run regardless of the privilege.
