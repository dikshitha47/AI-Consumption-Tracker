# Resource Budgets for AI

## Key Concepts

- Budgets are **class instances** (`SNOWFLAKE.CORE.BUDGET`), not standard objects.
- **Account budget** (`SNOWFLAKE.LOCAL.ACCOUNT_ROOT_BUDGET`): monitors all spending; does NOT support `ADD_RESOURCE`, `REMOVE_RESOURCE`, `SET_RESOURCE_TAGS`, or `GET_BUDGET_SCOPE`.
- **Custom budgets** (up to 100 per account): track specific resources via shared resources and user tags.

## Supported AI Shared Resource Domains

| Domain String | Specific Instance Support |
|--------------|--------------------------|
| `AI FUNCTION` | Yes — plain name string (e.g., `'AI_COMPLETE'`) |
| `CORTEX CODE` | Yes — plain name string (e.g., `'CORTEX_CODE_CLI'`) |
| `CORTEX AGENT` | No — domain-level only |
| `SNOWFLAKE INTELLIGENCE` | No — domain-level only |

---

## Create a Custom Budget for AI Spend

```sql
USE SCHEMA my_db.my_schema;
CREATE SNOWFLAKE.CORE.BUDGET my_ai_budget();
```

## Set a Spending Limit

```sql
CALL my_db.my_schema.my_ai_budget!SET_SPENDING_LIMIT(1000);
```

## Add AI Shared Resources

```sql
-- All Cortex Agents
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('CORTEX AGENT');

-- All AI Functions
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('AI FUNCTION');

-- A specific AI function only
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('AI FUNCTION', 'AI_COMPLETE');

-- All CoCo surfaces
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('CORTEX CODE');

-- A specific CoCo surface
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('CORTEX CODE', 'CORTEX_CODE_CLI');

-- All Snowflake Intelligence (CoWork)
CALL my_db.my_schema.my_ai_budget!ADD_SHARED_RESOURCE('SNOWFLAKE INTELLIGENCE');
```

## Associate Users via Tags (for Cost Attribution)

```sql
-- Tag users
ALTER USER alice SET TAG my_db.tags.cost_center = 'engineering';

-- Grant APPLYBUDGET on the tag
GRANT APPLYBUDGET ON TAG my_db.tags.cost_center TO ROLE budget_admin_role;

-- Set user tags on the budget
CALL my_db.my_schema.my_ai_budget!SET_USER_TAGS(
    [[(SELECT SYSTEM$REFERENCE('TAG', 'my_db.tags.cost_center', 'SESSION', 'APPLYBUDGET')), 'engineering']],
    'UNION'
);
```

## Configure Budget Notifications

```sql
-- Enable email notifications (requires notification integration)
CALL my_db.my_schema.my_ai_budget!SET_EMAIL_NOTIFICATIONS(
    PARSE_JSON('["admin@company.com"]')
);
```

## Inspect Budget State

```sql
-- List all budgets
SHOW SNOWFLAKE.CORE.BUDGET INSTANCES IN ACCOUNT;

-- Check spending limit
CALL my_db.my_schema.my_ai_budget!GET_SPENDING_LIMIT();

-- Check shared resources
CALL my_db.my_schema.my_ai_budget!GET_SHARED_RESOURCES();

-- Check budget scope (custom budgets only)
CALL my_db.my_schema.my_ai_budget!GET_BUDGET_SCOPE();

-- Check current spending
CALL my_db.my_schema.my_ai_budget!GET_SPENDING_HISTORY();
```

## Remove a Shared Resource

```sql
CALL my_db.my_schema.my_ai_budget!REMOVE_SHARED_RESOURCE('CORTEX AGENT');
```

## Drop a Budget

```sql
DROP SNOWFLAKE.CORE.BUDGET my_db.my_schema.my_ai_budget;
```
