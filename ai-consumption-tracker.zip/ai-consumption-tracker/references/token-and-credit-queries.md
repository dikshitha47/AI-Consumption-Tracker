# Token and Credit Queries

## All AI Usage History Views

| View | Product | Credits Column | User Column | Per-Model |
|------|---------|---------------|-------------|-----------|
| `CORTEX_AI_FUNCTIONS_USAGE_HISTORY` | AI Functions (AI_COMPLETE, AI_CLASSIFY, AI_EXTRACT, etc.) | `CREDITS` | `USER_ID` | `MODEL_NAME` |
| `CORTEX_AGENT_USAGE_HISTORY` | Cortex Agents | `TOKEN_CREDITS` | `USER_ID`, `USER_NAME` | Flatten `CREDITS_GRANULAR` |
| `SNOWFLAKE_COCO_USAGE_HISTORY` | CoCo (CLI, Desktop, Snowsight) | `TOKEN_CREDITS` | `USER_ID`, `USER_NAME` | Flatten `CREDITS_GRANULAR` |
| `SNOWFLAKE_COWORK_USAGE_HISTORY` | CoWork (fka Snowflake Intelligence) | `TOKEN_CREDITS` | `USER_ID`, `USER_NAME` | Flatten `CREDITS_GRANULAR` |
| `CORTEX_ANALYST_USAGE_HISTORY` | Cortex Analyst | `CREDITS` | `USERNAME` | No |
| `CORTEX_AI_GUARDRAILS_USAGE_HISTORY` | AI Guardrails | `TOKEN_CREDITS` | `USER_ID`, `USER_NAME` | No |
| `CORTEX_REST_API_USAGE_HISTORY` | Cortex REST API | **No credits column** | `USER_ID` | `MODEL_NAME` |
| `CORTEX_SEARCH_DAILY_USAGE_HISTORY` | Cortex Search | `CREDITS` | No | `MODEL_NAME` |
| `CORTEX_FINE_TUNING_USAGE_HISTORY` | Fine-Tuning | `TOKEN_CREDITS` | No | `MODEL_NAME` |
| `CORTEX_PROVISIONED_THROUGHPUT_USAGE_HISTORY` | Provisioned Throughput | `PTU_CREDITS` | No | `MODEL_NAME` |

All views are in `SNOWFLAKE.ACCOUNT_USAGE`. Requires `SNOWFLAKE.USAGE_VIEWER` database role or `IMPORTED PRIVILEGES` on the `SNOWFLAKE` database.

Organization-level equivalents exist in `SNOWFLAKE.ORGANIZATION_USAGE` (include `ACCOUNT_LOCATOR` in GROUP BY).

---

## Total AI Spend Across All Products (Last 30 Days)

```sql
WITH ai_spend AS (
    SELECT 'AI Functions' AS product,
           ROUND(SUM(CREDITS), 4) AS total_credits
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_FUNCTIONS_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'Cortex Agents',
           ROUND(SUM(TOKEN_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AGENT_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'CoCo',
           ROUND(SUM(TOKEN_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY
    WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'CoWork',
           ROUND(SUM(TOKEN_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COWORK_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'Cortex Analyst',
           ROUND(SUM(CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_ANALYST_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'AI Guardrails',
           ROUND(SUM(TOKEN_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_GUARDRAILS_USAGE_HISTORY
    WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'Cortex Search',
           ROUND(SUM(CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_SEARCH_DAILY_USAGE_HISTORY
    WHERE USAGE_DATE >= DATEADD('day', -30, CURRENT_DATE())
    UNION ALL
    SELECT 'Fine-Tuning',
           ROUND(SUM(TOKEN_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_FINE_TUNING_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    UNION ALL
    SELECT 'Provisioned Throughput',
           ROUND(SUM(PTU_CREDITS), 4)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_PROVISIONED_THROUGHPUT_USAGE_HISTORY
    WHERE INTERVAL_START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
)
SELECT product, COALESCE(total_credits, 0) AS total_credits
FROM ai_spend
WHERE total_credits > 0
ORDER BY total_credits DESC;
```

---

## AI Functions — Per-Model Token & Credit Breakdown

```sql
SELECT
    MODEL_NAME,
    ROUND(SUM(COALESCE(CREDITS, 0)), 4) AS total_credits,
    SUM(COALESCE(
        GET(FILTER(h.METRICS, x -> x:key:metric::STRING = 'input'
            AND x:key:unit::STRING = 'tokens'), 0):value::NUMBER, 0
    )) AS input_tokens,
    SUM(COALESCE(
        GET(FILTER(h.METRICS, x -> x:key:metric::STRING = 'output'
            AND x:key:unit::STRING = 'tokens'), 0):value::NUMBER, 0
    )) AS output_tokens,
    COUNT(DISTINCT QUERY_ID) AS total_queries
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_FUNCTIONS_USAGE_HISTORY h
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY MODEL_NAME
ORDER BY total_credits DESC;
```

---

## CoCo — Per-Model Credit Breakdown (via CREDITS_GRANULAR)

```sql
SELECT
    f.key AS model_name,
    ROUND(SUM(COALESCE(f.value:input::FLOAT, 0)), 4) AS input_credits,
    ROUND(SUM(COALESCE(f.value:output::FLOAT, 0)), 4) AS output_credits,
    ROUND(SUM(COALESCE(f.value:cache_read_input::FLOAT, 0)), 4) AS cache_read_credits,
    ROUND(SUM(COALESCE(f.value:cache_write_input::FLOAT, 0)), 4) AS cache_write_credits,
    ROUND(SUM(
        COALESCE(f.value:input::FLOAT, 0) + COALESCE(f.value:output::FLOAT, 0) +
        COALESCE(f.value:cache_read_input::FLOAT, 0) + COALESCE(f.value:cache_write_input::FLOAT, 0)
    ), 4) AS total_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY h,
     LATERAL FLATTEN(input => h.CREDITS_GRANULAR) f
WHERE h.USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY f.key
ORDER BY total_credits DESC;
```

---

## CoCo — Per-User, Per-Surface Breakdown

```sql
SELECT
    USER_NAME,
    INTERFACE AS surface,
    ROUND(SUM(TOKEN_CREDITS), 4) AS total_credits,
    SUM(TOKENS) AS total_tokens,
    COUNT(*) AS session_count
FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY
WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY USER_NAME, INTERFACE
ORDER BY total_credits DESC;
```

---

## Cortex Agents — Per-Model and Per-Service-Type Breakdown

```sql
WITH flattened AS (
    SELECT
        COALESCE(NULLIF(cf4.key, ''), 'unknown') AS model_name,
        cf3.key AS service_type,
        COALESCE(cf4.value:input::FLOAT, 0) + COALESCE(cf4.value:output::FLOAT, 0) +
        COALESCE(cf4.value:cache_read_input::FLOAT, 0) +
        COALESCE(cf4.value:cache_write_input::FLOAT, 0) AS total_credits,
        COALESCE(tf4.value:input::FLOAT, 0) + COALESCE(tf4.value:output::FLOAT, 0) +
        COALESCE(tf4.value:cache_read_input::FLOAT, 0) +
        COALESCE(tf4.value:cache_write_input::FLOAT, 0) AS total_tokens,
        h.REQUEST_ID
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AGENT_USAGE_HISTORY h,
         LATERAL FLATTEN(input => h.CREDITS_GRANULAR) cf1,
         LATERAL FLATTEN(input => cf1.value) cf2,
         LATERAL FLATTEN(input => cf2.value) cf3,
         LATERAL FLATTEN(input => cf3.value) cf4,
         LATERAL FLATTEN(input => h.TOKENS_GRANULAR) tf1,
         LATERAL FLATTEN(input => tf1.value) tf2,
         LATERAL FLATTEN(input => tf2.value) tf3,
         LATERAL FLATTEN(input => tf3.value) tf4
    WHERE cf2.key != 'start_time' AND tf2.key != 'start_time'
      AND cf1.index = tf1.index AND cf2.key = tf2.key
      AND cf3.key = tf3.key AND cf4.key = tf4.key
      AND h.START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
)
SELECT model_name, service_type,
    ROUND(SUM(total_credits), 4) AS total_credits,
    SUM(total_tokens) AS total_tokens,
    COUNT(DISTINCT REQUEST_ID) AS request_count
FROM flattened
GROUP BY model_name, service_type
ORDER BY total_credits DESC;
```

---

## Cortex REST API — Per-Model Token Breakdown (No Credits Column)

```sql
SELECT
    MODEL_NAME,
    COALESCE(SUM(TOKENS), 0) AS total_tokens,
    SUM(COALESCE(TOKENS_GRANULAR:input::NUMBER, 0)) AS input_tokens,
    SUM(COALESCE(TOKENS_GRANULAR:cache_read_input::NUMBER, 0)) AS cache_read_input_tokens,
    SUM(COALESCE(TOKENS_GRANULAR:output::NUMBER, 0)) AS output_tokens,
    COUNT(DISTINCT REQUEST_ID) AS request_count
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_REST_API_USAGE_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY MODEL_NAME
ORDER BY total_tokens DESC;
```

> **Note**: This view has no credits column. To estimate credits, apply per-model rates from the Service Consumption Table.

---

## Cortex Search — Daily Credit Usage

```sql
SELECT
    USAGE_DATE,
    SERVICE_NAME,
    CONSUMPTION_TYPE,
    MODEL_NAME,
    ROUND(SUM(CREDITS), 4) AS total_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_SEARCH_DAILY_USAGE_HISTORY
WHERE USAGE_DATE >= DATEADD('day', -30, CURRENT_DATE())
GROUP BY USAGE_DATE, SERVICE_NAME, CONSUMPTION_TYPE, MODEL_NAME
ORDER BY USAGE_DATE DESC, total_credits DESC;
```

---

## Fine-Tuning — Credit Usage by Model

```sql
SELECT
    MODEL_NAME,
    ROUND(SUM(TOKEN_CREDITS), 4) AS total_credits,
    SUM(TOKENS) AS total_tokens
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_FINE_TUNING_USAGE_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY MODEL_NAME
ORDER BY total_credits DESC;
```

---

## Provisioned Throughput — PTU Credit Usage

```sql
SELECT
    MODEL_NAME,
    ROUND(SUM(PTU_CREDITS), 4) AS total_ptu_credits
FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_PROVISIONED_THROUGHPUT_USAGE_HISTORY
WHERE INTERVAL_START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
GROUP BY MODEL_NAME
ORDER BY total_ptu_credits DESC;
```

---

## Daily AI Spend Trend (All Products Combined)

```sql
WITH daily AS (
    SELECT DATE_TRUNC('day', START_TIME)::DATE AS day, 'AI Functions' AS product, SUM(CREDITS) AS credits
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AI_FUNCTIONS_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP()) GROUP BY 1
    UNION ALL
    SELECT DATE_TRUNC('day', START_TIME)::DATE, 'Cortex Agents', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_AGENT_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP()) GROUP BY 1
    UNION ALL
    SELECT DATE_TRUNC('day', USAGE_TIME)::DATE, 'CoCo', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COCO_USAGE_HISTORY
    WHERE USAGE_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP()) GROUP BY 1
    UNION ALL
    SELECT DATE_TRUNC('day', START_TIME)::DATE, 'CoWork', SUM(TOKEN_CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.SNOWFLAKE_COWORK_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP()) GROUP BY 1
    UNION ALL
    SELECT DATE_TRUNC('day', START_TIME)::DATE, 'Cortex Analyst', SUM(CREDITS)
    FROM SNOWFLAKE.ACCOUNT_USAGE.CORTEX_ANALYST_USAGE_HISTORY
    WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP()) GROUP BY 1
)
SELECT day, product, ROUND(credits, 4) AS credits
FROM daily
ORDER BY day DESC, credits DESC;
```
