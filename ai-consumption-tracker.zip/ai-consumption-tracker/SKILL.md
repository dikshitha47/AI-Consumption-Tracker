---
name: ai-consumption-tracker
description: AI cost management and governance guidance. Use when: tracking AI credit usage, setting AI budgets, configuring per-user CoCo limits, querying token consumption by model, understanding Cortex pricing, scoping AI function access with roles, attributing AI spend to teams. Triggers: AI cost, AI credits, AI spend, AI budget, cortex budget, cortex agent budget, shared resource budget, resource budget, CoCo credit limit, credit limit, per-user CoCo limit, token count, token breakdown, per-model tokens, cortex pricing, AI_FUNCTIONS_USER, AI function access, USE AI FUNCTIONS, per-user quota, AI quota, cortex agent cost, CoCo cost, CoWork cost, cortex analyst cost, cortex search cost, fine-tuning cost, provisioned throughput cost, PTU cost, AI guardrails cost, AI governance, AI access control, model access control, CORTEX_USER, CORTEX-MODEL-ROLE-ALL, AI cost attribution, AI chargeback, Cortex pricing reference.
---

# AI Consumption Tracker

> AI cost management and governance for Snowflake Cortex.

## Routing

Match the user's question to keywords, then read the corresponding reference file before writing any SQL.

| Keywords | Reference File |
|----------|----------------|
## | "token count", "per-model breakdown", "credits by model", "AI usage", "how much did we spend on AI", "which model costs most", "token usage", "CREDITS_GRANULAR", "TOKENS_GRANULAR" | `references/token-and-credit-queries.md` |
| "budget", "spending limit", "create budget", "cortex agent budget", "shared budget", "AI budget", "add shared resource", "shared resource budget", "resource budget", "cortex agent budget", "agent budget", "coco budget" | `references/resource-budget.md` |
## | "CoCo limit", "daily credit limit", "CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER", "CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER", "CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER", "block CoCo", "restrict CoCo" | `references/coco-credit-limits.md` |
## | "quota", "per-user limit", "per-user quota", "block enforcement", "AI quota" | `references/quotas.md` |
## | "AI_FUNCTIONS_USER", "CORTEX_USER", "USE AI FUNCTIONS", "per-function privilege", "AI access control", "who can use AI", "restrict AI", "opt out AI", "model access", "CORTEX-MODEL-ROLE-ALL" | `references/access-control.md` |
## | "pricing", "credit per token", "service consumption table", "how much does a model cost", "cortex pricing" | `references/pricing.md` |
## | "attribution", "chargeback", "AI cost by team", "AI cost by tag", "QUERY_TAG", "AI guardrails cost" | `references/attribution.md` |

If a question spans multiple topics, load all relevant reference files before responding.

Never write ad-hoc queries when a verified query exists in a reference file.

---

## Workflow

### Step 1: Classify the Request

Determine which category the user's question falls into:

1. Observe — "How much are we spending on AI?" → token/credit queries
2. Control — "Set a budget/limit/quota" → budgets, CoCo limits, or quotas
3. Govern — "Who can use AI functions?" → access control
4. Price — "How much does model X cost?" → pricing references
5. Attribute — "Which team is driving AI spend?" → attribution

### Step 2: Load Reference and Execute

Read the matched reference file(s) from the routing table above. Use the verified SQL patterns — do not improvise queries when a reference exists.

### Step 3: Present Results

- For Observe questions: show credits, tokens, model breakdown, and trend
- For Control questions: provide the exact SQL commands and confirm execution
- For Govern questions: show current grants and recommend changes
- For Price questions: link to the Service Consumption Table and explain the model
- For Attribute questions: show spend by tag/user/team

**⚠️ STOP**: Before executing any ALTER ACCOUNT, ALTER USER, CREATE BUDGET, DROP, CREATE QUOTA, GRANT, or REVOKE statement, confirm with the user and only then proceed.

---

## Key Facts (Always Apply)

1. **Budget syntax**: Budgets are class instances. Use `SHOW SNOWFLAKE.CORE.BUDGET INSTANCES IN ACCOUNT` — never `SHOW BUDGETS`.
2. **Account budget limitations**: `SNOWFLAKE.LOCAL.ACCOUNT_ROOT_BUDGET` does NOT support `ADD_RESOURCE`, `REMOVE_RESOURCE`, `SET_RESOURCE_TAGS`, or `GET_BUDGET_SCOPE`. Use a custom budget for targeted tracking.
3. **QUERY_TAG does not work for AI cost attribution**: None of the AI usage-history views have a `QUERY_TAG` column. Use user tags or object tags instead.
4. **AI Guardrails credits are additive**: They're charged on top of the triggering product's credits.
5. **CORTEX_REST_API_USAGE_HISTORY has no credits column**: Only tokens. To estimate credits, apply rates from the Service Consumption Table manually.
6. **CoCo daily limits vs quotas**: Daily credit limits are a quick per-surface cap. Quotas are more flexible (monthly/daily, notifications, block enforcement, custom actions). They are complementary.
7. **Legacy views**: `CORTEX_CODE_CLI_USAGE_HISTORY`, `CORTEX_CODE_DESKTOP_USAGE_HISTORY`, `CORTEX_CODE_SNOWSIGHT_USAGE_HISTORY` still work but are superseded by the unified `SNOWFLAKE_COCO_USAGE_HISTORY`. Similarly, `SNOWFLAKE_INTELLIGENCE_USAGE_HISTORY` is replaced by `SNOWFLAKE_COWORK_USAGE_HISTORY`.
8. Never invent token counts, credits, prices, models, roles, grants, budgets, limits, tags, users, or account configuration.
9. Never infer actual token counts from credits when authoritative usage metrics are available.
10. For impactful administrative changes, clearly state the effect and required authorization before execution.
11. If required information cannot be obtained, state what is unavailable. Do not fill gaps with assumptions.
12. Warn the user before suggesting operations that revoke, drop, create, alter access.
13. Prefer least-privilege access.
14. Respect the authenticated user's Snowflake permissions. Never attempt to bypass RBAC.

## Output

- Verified SQL queries with results
- Show all the necessary metrics
- Actionable governance recommendations
- Links to Snowflake documentation where relevant
